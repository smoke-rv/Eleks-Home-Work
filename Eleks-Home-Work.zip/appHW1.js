//1. Write a JS program to compute and print the sum of the two given integers
let a = 10;
let b = 38;
console.log(a + b);

//2. Write a JS program to create a new string adding “Test_" in front of a given string
let string = "my string";
console.log("Test_" + string);

//3. Write a JS program to combine and print your first, last name and age
let firstName = "Vadim";
let lastName = "Polishchuk";
let age = 37;
console.log(firstName + " " + lastName + ", " + age);

//4. Write a JS program to check a given integer is bigger then 100
let c = 198;
console.log(c > 100);

//5. Write a JS program to find if the first number is larger from the two given positive integers
let d = 26;
let e = 10;
console.log(d > e);

//6. Write a JS program to check two given numbers and return true if one of the number is 50 or if their sum is 50
let f = 35;
let g = 15;
console.log(f == 50 && g == 50 || f + g == 50);

//7. Write a JS program check if a given positive number is a multiple of 3 or a multiple of 7
let h = 45;
console.log(h % 3 == 0 || h % 7 == 0);